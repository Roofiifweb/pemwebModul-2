let todoList = [];

function addTask() {
    const inputElement = document.getElementById('todo-input');
    const task = inputElement.value.trim();

    if (task) {
        todoList.push({ text: task, isEditable: false });
        inputElement.value = '';
        renderTasks();
    } else {
        alert('Please enter a valid task.');
    }
}

function renderTasks() {
    const listElement = document.getElementById('todo-list');
    listElement.innerHTML = '';

    todoList.forEach((task, index) => {
        const listItem = document.createElement('li');

        if (task.isEditable) {
            const editInput = document.createElement('input');
            editInput.value = task.text;
            listItem.appendChild(editInput);

            const saveButton = document.createElement('button');
            saveButton.textContent = 'Save';
            saveButton.className = 'edit-btn';
            saveButton.onclick = () => saveEdit(index, editInput.value);
            listItem.appendChild(saveButton);
        } else {
            const taskText = document.createElement('span');
            taskText.textContent = task.text;
            listItem.appendChild(taskText);

            const editButton = document.createElement('button');
            editButton.textContent = 'Edit';
            editButton.className = 'edit-btn';
            editButton.onclick = () => editTask(index);
            listItem.appendChild(editButton);
        }

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.className = 'delete-btn';
        deleteButton.onclick = () => deleteTask(index);
        listItem.appendChild(deleteButton);

        listElement.appendChild(listItem);
    });
}

function editTask(index) {
    todoList[index].isEditable = true;
    renderTasks();
}

function saveEdit(index, newValue) {
    if (newValue.trim()) {
        todoList[index].text = newValue;
        todoList[index].isEditable = false;
        renderTasks();
    } else {
        alert('Task cannot be empty.');
    }
}

function deleteTask(index) {
    todoList.splice(index, 1);
    renderTasks();
}